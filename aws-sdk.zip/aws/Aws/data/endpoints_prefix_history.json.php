<?php
// This file was auto-generated from sdk-root/src/data/endpoints_prefix_history.json
return [ 'prefix-groups' => [ 'api.ecr' => [ 'ecr', ], 'api.sagemaker' => [ 'sagemaker', ], 'ecr' => [ 'api.ecr', ], 'sagemaker' => [ 'api.sagemaker', ], ],];
