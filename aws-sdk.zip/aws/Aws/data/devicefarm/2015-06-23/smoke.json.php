<?php
// This file was auto-generated from sdk-root/src/data/devicefarm/2015-06-23/smoke.json
return [ 'version' => 1, 'defaultRegion' => 'us-west-2', 'testCases' => [ [ 'operationName' => 'ListDevices', 'input' => [], 'errorExpectedFromService' => false, ], [ 'operationName' => 'GetDevice', 'input' => [ 'arn' => 'arn:aws:devicefarm:us-west-2::device:000000000000000000000000fake-arn', ], 'errorExpectedFromService' => true, ], ],];
